#!/bin/bash
#
<<note
demo for varaiable
note

read -p "Enter the name" name
echo "My name is $name--"

read -p "Enter your name" name2
echo "My another name is $name2"
