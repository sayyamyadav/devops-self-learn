ls /home/sayyam
