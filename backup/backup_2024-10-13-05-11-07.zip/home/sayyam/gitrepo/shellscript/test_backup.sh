#!/bin/bash
#dATE:12/10/24
#
#

src_dir=$1
des_dir=$2
timestamp="$(date +'%Y-%m-%d-%h-%s')"
backup_dir="${des_dir}/${timestamp}_backup"

function create_dir {
	zip -r "${backup_dir}.zip" "${src_dir}" > /dev/null
	if [ $? -eq 0 ]; then
	       echo "backup successfully created"
       else
               echo "something went wrong"
	fi	       
}


create_dir
