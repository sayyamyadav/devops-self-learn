#!/bin/bash
#Authore:Sayyam Yadav
#Date: 11/9/2024
#
#
# task to perform 
#
#
# create directory my project inside that create subfolder soure,bin,doc
# print the current directoryy you are at
# move inside source folder
# and then print current  directory yu are at


# create a myProjectFold 
mkdir myProject
cd myProject

# create subfolder src,bin and doc
#
mkdir src bin doc

#print the currrent dirc you are at#

pwd
# mv to src folder
cd src
# print the current directory yo are at
#
pwd


###
#for list out all the file we can use 
#
ls -ltr
