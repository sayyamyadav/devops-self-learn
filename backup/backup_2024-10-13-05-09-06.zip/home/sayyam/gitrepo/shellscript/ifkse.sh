#!/bin/bash
#Authore: Sayyam
#Date: 9/9/2024
# if else loop in shell script excuation
#
#
a=4
b=4

if [$a == $b]
then
	echo "print a and b are equal"
else
	echo "a and b are not equal"
fi

