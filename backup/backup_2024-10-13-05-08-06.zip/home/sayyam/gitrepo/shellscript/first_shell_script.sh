#!/bin/bash
echo "my name is sayyam"
