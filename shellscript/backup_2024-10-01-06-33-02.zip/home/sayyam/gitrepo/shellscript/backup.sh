#!/bin/bash
#Date:1/10/2024
#
<< readme
this script is for takup backup of given directory
usage:
./backup.sh <path of directory>
readme

source_dir=$1
timestamp=$(date '+%Y-%m-%d-%H-%M-%S')

bckup_dir="${source_dir}/backup_${timestamp}"

echo $bckup_dir

zip -r "${bckup_dir}.zip" "${source_dir}" > /dev/null
if [ $? -eq 0 ]; then
echo "backup create successfully"
else
	echo "backup was not perform for that particular $timestamp"
fi
